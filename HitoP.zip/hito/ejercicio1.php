<?php   

class Padre {
 
    public $numero=3; 
    public $nombre = "Hector"; 
    public $boleano = false; 

    public function __constructor($numero, $nombre, $boleano){

        $numero = $this->$numero;
        $nombre = $this->$nombre;
        $boleano = $this->$boleano;
    }

    public function andar() {
        echo("<p>El numero ".$this->numero." y el nombre ".$this->nombre.
        " es cierto ".$this->boleano."</p>");
    }
}


class Hijo extends Padre {

    public function andar() {
        echo("<p>Persona andando pero de Hijo</p>");
    }

    public function Suma($numero1, $numero2){       
        return $numero1+$numero2;
   }

}





