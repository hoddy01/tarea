<?php

function tienda($precio,$unidades,$descuento){
    $totalSinDescuento=$precio*$unidades;

    if ($descuento == true) {
        $total=$totalSinDescuento-($totalSinDescuento*0.15);
    }else
    {
        $total=$totalSinDescuento;
    }
    return "<p> El total es: ".$total."</p>";
}