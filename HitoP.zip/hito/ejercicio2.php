<?php

Interface ejercicio{
    public function uno($nombre);
    public function dos();
}

class ejercicio2 implements ejercicio{

    public function uno($nombre){
        echo("<p>Primera ".$nombre." función</p>");
    }
    public function dos(){
        echo("<p>Segunda función</p>");
    }
}

