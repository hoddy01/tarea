<?php

$numero = $_POST['numero'];
echo("<h4>Los numeros primos desde 0 hasta el numero indicado son: </h4>");
for ($i=0; $i<=$numero; $i++){
    if($i!=2 && $i%2!=0){
        echo("<p> ".$i." </p>");
    }
}
?>






