<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HitoProgramacion</title>
</head>
<body>
    <h1>HitoProgramacionT2</h1>
<?php

include_once('ejercicio1.php');
include_once('ejercicio2.php');
include_once('ejercicio3.php');

echo("<h2>Ejercicio1</h2>");
$padre1 = new Padre();
$padre1->andar();
$hijo1 = new Hijo();
echo($hijo1->Suma(5,6));
$jpepe = new Hijo();
$jpepe->andar();

echo("<h2>Ejercicio2</h2>");
$manolo = new ejercicio2();
$manolo->uno("Pedrito");
$manolo->dos();

echo("<h2>Ejercicio3</h2>");
echo(tienda(16.2,2,false));

?>

<h2>Ejercicio4</h2>
<form action="ejercicio4.php" method="POST">
<label>Dime un numero:</label>
<input type="number" id="numero" name="numero">
<input type="submit">
</form>

<?php
echo("<h2>Ejercicio5</h2>");
$resultado=fn($numero)=>$numero*$numero;
var_export($resultado(5));

echo("<h2>Ejercicio6</h2>");
//Quiero que me multipliques los primeros 20 numeros por 2
const constante = 2;
for ($i=1; $i < 5; $i++) { 
    $resultado1 = $i*constante;
    echo($resultado1."<br>");
}

echo("<h2>Ejercicio7</h2>");
echo("<h5>Unario</h5>");
for($i=0;$i<5;$i++){
    echo($i."</br>");
}
echo("<h5>Binario</h5>");
for ($i=0; $i < 5; $i++) { 
    $resultado1 +=$i;
    echo($resultado1."</br>");
}
echo("<h5>Terciario</h5>");
for ($i=0; $i < 5; $i++) { 
    $multiplicando = $i*2*3*4/3;
    $resultado1 +=($i*$multiplicando);
    echo($resultado1."</br>");
}

?>
</body>
</html>
